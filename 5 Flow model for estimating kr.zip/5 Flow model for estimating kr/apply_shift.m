%%  SUBROUTINE: SHIFT AN INPUT IMAGE TO ALIGN WITH A REFERENCE IMAGE  %%
%
% OVERVIEW:
%   This code will use two OR three inputs. If given ONLY TWO inputs, 
%   (1) image requiring shift, (2) amount of shift needed, the code 
%   will shift the ENTIRE image and cut off the edges. If given THREE  
%   inputs, (1) image requiring shift, (2) amount of shift needed, (3)
%   region of interest (roi), the code will ONLY shift the input roi.
%
% INPUTS:
%   - im = input image; input image that has shifted from a reference image
%   - shift = shift in i and j direction (get from: <<full_pixel_shift>>)
%   - [roi] = region of interest;[..] refers to a secondary argument for 
%   this code. i.e. this code can shift either that whole image or just 
%   a specified roi.
%
% OUTPUTS:
%   - imS = image shifted; the image after it is shifted to the refernce
%   image location. This image is now "registered" to the reference image.
%
% DEVELOPED BY:
%   Ricardo Medina and Trevor Jones (9/17/2013)
%
% FIXED BUG IN ORIGINAL CODE ('apply_shift_image')
%
%%
function [imS] = apply_shift(im,shift)
    warning off; 
    
    [ni nj] =  size(im);
    
    dt_i = shift(1);
    dt_j = shift(2);
    
    A = zeros(size(im));
    
    %Define the range for i and j of the current image (im) 
    i_int = 1;
    i_fin = ni;
    j_int = 1;
    j_fin = nj;
    
    A_i_int = i_int-(heaviside(-dt_i)*(dt_i));
    A_i_fin = i_fin-(heaviside(dt_i)*(dt_i));
    A_j_int = j_int-(heaviside(-dt_j)*(dt_j));
    A_j_fin = j_fin-(heaviside(dt_j)*(dt_j));
    
    im_i_int = i_int+(heaviside(dt_i)*(dt_i));
    im_i_fin = i_fin+(heaviside(-dt_i)*(dt_i));
    im_j_int = j_int+(heaviside(dt_j)*(dt_j));
    im_j_fin = j_fin+(heaviside(-dt_j)*(dt_j));
    
    A(A_i_int:A_i_fin,A_j_int:A_j_fin)=im(im_i_int:im_i_fin,im_j_int:im_j_fin);
                    
    imS=A;
    
end
