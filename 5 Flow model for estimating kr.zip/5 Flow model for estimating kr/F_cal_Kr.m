function [ Kr ] = F_cal_Kr( imResidual, bh )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

Dh=0.716; % water head difference applied (m)

g=9.8; % acceleration of gravity g (m/s2)
nu=1.00678*10^(-6); % kinematic viscosity �� (m2/s)
K_sat = (bh*10^(-6))^2*g/(12*nu); % hydraulic conductivity of fully saturated fracture (m/s)
b_sat = bh*ones(size(imResidual,1),size(imResidual,2)); % aperture field for fully saturated fracture (um)
b_par = bh*double(~imResidual); % aperture field for partially saturated fracture (um)
T_sat = K_sat*b_sat*10^(-6); % transmissivity (m2/s)
T_par = K_sat*b_par*10^(-6);

T_sat_end=T_sat(:,end);
T_par_end=T_par(:,end);

for jj=1:2
    if jj==1
        t=T_sat;
    else
        t=T_par;
    end

    % pad t array with one extra row of 'ghost' cells around entire domain
    t=padarray(t,[1 1],'symmetric'); % 'symmetric' uses corresponding value inside domain for 'ghost' cell value
    nx=size(t,1); ny=size(t,2);   % note, we're defining nx and ny for padded array - actual domain is nx-2 x ny-2

    % set t=0 in 'ghost' cells adjacent to no flow boundaries
    t(1,:)=0; t(nx,:)=0;  
%     figure(2)
%     imshow(t,[],'Colormap',jet);impixelinfo
    % pause()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   Calculate head field    %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % initialize vectors
    b=zeros(nx-2,ny-2); % right-hand-side vector
    h=b;                % specified heads (used for calculating rhs)
    % indices of constant head boundaries 
    % (applied along j=1 and j=ny boundaries for this example)
    ch_bound=1:nx-2;
    % set constant head value on left-hand B.C.; assume right-hand head=0
    h(ch_bound,1)=Dh; % (m��
%     tic

    % Build coefficient matrix [A] and RHS vector {b}
    %i=1:nx-1; j=1:ny-1;
    % offdiagonal terms
    i=2:nx-1; j=2:ny-1;
    % offdiagonal terms
    ip = 2./(1./t(i+1,j) + 1./t(i,j));
    in = 2./(1./t(i-1,j) + 1./t(i,j));
    jp = 2./(1./t(i,j+1) + 1./t(i,j));
    jn = 2./(1./t(i,j-1) + 1./t(i,j));
    % diagonal terms
    diag=-in-jn-jp-ip;

    % modify right hand side for constant head B.C.s on left and right
    b(ch_bound,1)=-jn(ch_bound,1).*h(ch_bound,1);
    b(ch_bound,ny-2)=-jp(ch_bound,ny-2).*h(ch_bound,ny-2);
    % % sink (well)
    % b(sink(1,1),sink(1,2))=Q;

    % assemble equations
    B=[jn(:) in(:) diag(:) ip(:) jp(:)];
    d=[(nx-2),1,0,-1,-(nx-2)];
    neq=(nx-2)*(ny-2);
    a=spdiags(B,d,neq,neq)';  
%     toc

%     tic
    % solve for flow field
    h=a\b(:);
%     toc

    % check sum of residuals - should be close to zero
    r=(a*h-b(:)).^2;  
    r=sum(r(:));

    h=reshape(h,nx-2,ny-2);

%     figure(1);
%     subplot(1,2,1)
%     imshow(h,[],'Colormap',jet);impixelinfo
%     axis equal
%     %axis([1 nx-1 1 ny-1])
%     subplot(1,2,2)
%     contour(h,20)
%     axis equal
%     pause()

    if jj==1
        Q(1,jj)=sum(T_sat(:,end).*h(:,end));
        h_sat_end(:,1)=h(:,end);
    else
        Q(1,jj)=sum(T_par(:,end).*h(:,end));
        h_par_end(:,1)=h(:,end);
    end
end
Kr=Q(:,2)./Q(:,1); 


end

