function shift = full_pixel_shift_new(reference, test, io, jo, size_tmp, nshift)
%FULL_PIXEL_SHIFT measure amount of shift between pair of images
%    
%
%   SHIFT = full_pixel_shift(REFERENCE, TEST, IO, JO, SIZE_TMP, NSHIFT)
%
%   Inputs:
%   REFERENCE - 2D reference image.
%
%   TEST - 2D test image (should be same size as reference)
%
%   IO, JO - i and j index of the center of the region to test for 
%   alignment
%
%   SIZE_TMP - size of the template to use for checking (equivalent to 
%   box_size in old version)
%
%   NSHIFT - number of pixels to shift through to check alignment (the 
%   following must be true: NSHIFT < SIZE_TMP)
%
%   Outputs:
%   SHIFT - 
%   Note:   IO-SIZE_TMP and JO-SIZE_TMP must be > 0
%           IO+SIZE_TMP and JO+SIZE_TMP must be <= size(REFERENCE)
%

% Test that region to be checked doesn't extend beyond reference image 
[nx ny] = size(reference);
i_begin = io-nshift;
i_end = io+nshift;
j_begin = jo-nshift;
j_end = jo+nshift;

if (i_begin <= 0) || (i_end > nx) || (j_begin <= 0) || (j_end > ny),
    error('you asked me to check regions that fall outside of image boundaries')
    return
end

% Define ROI in reference image
reference_roi = reference(i_begin:i_end,j_begin:j_end);

% Test that region to be checked doesn't extend beyond test image
[nx ny] = size(test);
i_begin = io-size_tmp;
i_end = io+size_tmp;
j_begin = jo-size_tmp;
j_end = jo+size_tmp;

if (i_begin <= 0) || (i_end > nx) || (j_begin <= 0) || (j_end > ny),
    error('you asked me to check regions that fall outside of image boundaries')
    return
end

% Define ROI in test image
test_roi = test(i_begin:i_end,j_begin:j_end);

% Calculate cross-correlation matrix
c = normxcorr2(reference_roi,test_roi);

% Define location corresponding to zero shift in cross-correlation matrix
delta=size_tmp+nshift+1;


% Find location of peak - actual shift
[max_c, imax] = max(abs(c(:)));
[ipeak, jpeak] = ind2sub(size(c),imax(1));

% this crashes on occasion - not sure why; perhaps two locations 
% with max value? but the above version seems more robust
%[xpeak ypeak] = find(c == max(abs(c(:)))) 

shift = [(ipeak - delta) (jpeak- delta)];
%cimshow(c)
end
