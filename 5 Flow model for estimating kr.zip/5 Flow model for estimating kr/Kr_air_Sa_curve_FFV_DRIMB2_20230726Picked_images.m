%% Comments in 20230726
% This script was modified to suitable for processing picked images (the
% first and the last 10 images of each pressure step

%%
clc;clear all;close all;
tic;
%% deal with PVC edges
imPVCedges = imread('FFV-DRIMB2-imBinary-step5dh=-361-start.tif');
imPVCedges(1:1800,1:1840)=0;
imPVCedges(150:180,1885:1925)=0;
imPVCedges(1900:1920,1500:1530)=0;
% f10=figure(10); imshow(imPVCedges,[],'colormap',hot,'border','tight');impixelinfo
tic
%% Initial settings
bh=51.44; % hydraulic aperture (um) % FF=51.44; MF=46.06
folder_save='G:\data_for_sharing\5 Flow model for estimating kr_modified\relative permeability\';
floder_save_im='G:\data_for_sharing\5 Flow model for estimating kr_modified\relative permeability\imBinary_start&end\';
SeText='FFV_2nd_DR-IMB';DateText='20230726';
Sa_xls_Name = fullfile(folder_save,'Kr_air_Sa_Data20230726.xls');

% step_num_DP = 12; % the final step number of drainage process
% step_num_DRstart=6;step_num_IMBend=20;

%% Load reference image & pick up reference window
folder_ref='G:\data_for_sharing\1 averaged reference image\'; % reference image
ref = imread([folder_ref,'ave_ref_image_for_FFV.tiff']);
ref = imrotate(ref,-0.8,'nearest','crop'); % rotate the image a little bit.

% Registration Reference: iref = row, jref = col 
iref = 654; jref = 297;  %i and j index of the center of the region to test for alignment
boxsize = 60;
nshift = 20;
idx = [325 684 17 131]; %[row1 row2 col1 col2]
Wref = double(ref(idx(1):idx(2),idx(3):idx(4)));
roi_ref = [iref-boxsize iref+boxsize jref-boxsize jref+boxsize];

%% Settings for image display in video
% Define ROI for images
roi = [27 2048 1062 3072]; %[row1 row2 col1 col2] %% the bottom & right edges are a little out of the Camera field.
imref = double(ref(roi(1):roi(2),roi(3):roi(4))); % cut off the image boundary
[row,col]=size(imref); % get the image size

folder1='G:\data_for_sharing\2 experimental images at the end of each sequence\FFV\2nd_DR-IMB\'; % raw images folder.
dinfo = dir(fullfile(folder1, '*.tiff')); % read the files' name and some other information. % f=fullfile(filepart1,...,filepartN) builds a full file specification from the specified folder and file names. On windows the file separator character is a backslash (\).
imagename=char({dinfo.name}); % Only pick the name info., it's a row vector. Note that this make iN be a cell array, not string array
N=size(imagename,1); % Count the number of files;
iNum = str2num(imagename(:,end-8:end-5)); % image number

%% Load & process data
% %% Read time/mass/pressure data
DATA=importdata([folder1,'1203V_DR_IMB2.txt']);  
Data=DATA.data; % here 1-Elapsed time (sec);2-scale;3-Pressure transducer (V);4-image number.
dh=87.473*Data(:,3)+27.502-208.5+76;  % (mm)
t=Data(:,1);
m=Data(:,2);

% 2nd
% Drainage: 14 pressure steps; Imbibition: 8 steps
imPoint=[49,100;199,400;489,600;949,1050;1129,1230;1309,1429;1529,1630;...
    1799,1900;1999,2100;2199,2360;2429,2780;2899,3000;3099,3210;3339,3440;...
    3599,3700;3799,3900;3999,4100;4449,4580;4649,4750;4869,5000;5089,5200;5299,5659;5709,N-1];

imPoint(:,3) = imPoint(:,2)-imPoint(:,1)+1;
imTotalNum(1,1)=0;
for iTN = 1:length(imPoint)-1
    imTotalNum (iTN+1,1) = sum(imPoint(1:iTN,3));
end
%% Mask of 6 inlet/outlet Grooves
imGrooves = ones(col,row);
imGrooves([1:111],[475:550,970:1065,1460:1540]) = 0;
imGrooves([1901:2011],[475:570,980:1070,1480:1545]) = 0;
imGrooves([1847:1862],[410:1670]) = 0; % PVC gasket edges, for modifieded
imGrooves90 = imrotate(imGrooves,90);
imGrooves2 = ones(col,row);
imGrooves2([1:111],:) = 0;
imGrooves2([1901:2011],:) = 0;
imGrooves2([1847:1862],[410:1670]) = 0; % PVC gasket edges, for modifieded
imGrooves290 = imrotate(imGrooves2,90);
% f11=figure(11); imshow(imGrooves90,[],'colormap',hot,'border','tight');impixelinfo
% f111=figure(111); imshow(imGrooves290,[],'colormap',hot,'border','tight');impixelinfo
%% Boundary condition
Mask_unglued = zeros(col,row);
Mask_unglued([37:1976],[42:1981]) = 1;

%% Parameters initialization
% threshold value and range
T_c=0.094;
T_ratio = [-15,0,15];
T_point = (1+T_ratio./100).*T_c;

%% Process images
for step_num = 1:length(imPoint)-1 
    dh_ave(step_num,:)=mean(dh(imPoint(step_num,1)+1:imPoint(step_num,2)+1));
    imPro_idx = [imPoint(step_num,1)+1,imPoint(step_num,2)-8:imPoint(step_num,2)+1];
    Lidx = length(imPro_idx);
    
    for i = Lidx*(step_num-1)+1:Lidx*(step_num)
        t_reset(i,1)=t(imPro_idx(i-Lidx*(step_num-1)))-t(imPoint(step_num,1)+1);
        % %% Read experimental images
        filename1 = fullfile(folder1,imagename(i,:)); % combine filename & folder name to char. or str.
    %     filename2 = fullfile(folder2,imagename(i,:));
        imraw = imread(filename1);
        imraw = imrotate(imraw,-0.8,'nearest','crop');
        % %% Register and shift image
        shift = full_pixel_shift_new(ref,imraw,iref,jref,boxsize,nshift);
        shf(i,:)=shift;
        imraw = apply_shift(imraw,shift);
        % %% Normalization 
        Wim = double(imraw(idx(1):idx(2),idx(3):idx(4)));
        R = Wref./Wim;
        R_norm = mean(R(:));
        % %% Absorbance Field
        imroi = double(imraw(roi(1):roi(2),roi(3):roi(4)));
        imroi = imroi .* R_norm;
        % imroi =rot90(imroi,3);
        imAbs_Field = log(imroi./imref);
        imAbs_Field(imref==0) = min(min(imAbs_Field)); % As the image was rotated a little bit, 0s were introduced into it.
        imAbs_Field90 = imrotate(imAbs_Field,-90);
%         f13=figure(13); imshow(imAbs_Field90,[-0.2,0.4],'colormap',jet,'border','tight');impixelinfo

    % %% try segmentation
        for j = 1:length(T_point)
            imBw_wo4pixels = imNor_to_imBwFinal( imAbs_Field90, Mask_unglued, T_point(j) );
            imBw_wo4pixels = imBw_wo4pixels.*double(~imPVCedges);
%             f14=figure(14); imshow(imBw_wo4pixels,[],'colormap',hot,'border','tight');impixelinfo
%             f15=figure(15); imshow(~imBw_wo4pixels,[],'colormap',hot,'border','tight');impixelinfo
%             f1=figure(1); imshow(imBw_wo4pixels,[],'colormap',hot,'border','tight');impixelinfo
          
            CC_new = bwconncomp(imBw_wo4pixels,4);
            imLabel_num_save(i,j) = CC_new.NumObjects;
            imLabel_num_save_Nrow(i,1)=imPro_idx(i-Lidx*(step_num-1))-1;
            
%             %%caculate the air saturation
            imSaturation(i,j)=sum(sum(imBw_wo4pixels))/(row*col);
            imResidual = imrotate(imBw_wo4pixels,90);
%             f2=figure(2); imshow(imResidual,[],'colormap',hot,'border','tight');impixelinfo
%             f17=figure(17); imshow(~imResidual,[],'colormap',hot,'border','tight');impixelinfo
            
            Kr(i,j) = F_cal_Kr( imResidual, bh );
            
            %%!!!!!!!!!!!!!!!!!%% calculate the Kr of air phase 20221023
            imResidual_air = double(~imrotate(imBw_wo4pixels,90)).*double(imGrooves90);
%             f18=figure(18); imshow(imResidual_air,[],'colormap',hot,'border','tight');impixelinfo
%             f181=figure(181); imshow(imrotate(imResidual_air,-90),[],'colormap',hot,'border','tight');impixelinfo
%             f19=figure(19); imshow(~imResidual_air,[],'colormap',hot,'border','tight');impixelinfo
            Kr_air(i,j) = F_cal_Kr(imResidual_air, bh );
            imResidual_air2 = double(~imrotate(imBw_wo4pixels,90)).*double(imGrooves290);
%             f182=figure(182); imshow(imResidual_air2,[],'colormap',hot,'border','tight');impixelinfo
            Kr_air2(i,j) = F_cal_Kr(imResidual_air2, bh );
            
            if T_point(j)==T_c
                if i==Lidx*(step_num-1)+1
                    imBwName = fullfile(floder_save_im,[SeText,'-imBinary-step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-start','.tif']);
                    imwrite(imBw_wo4pixels,imBwName);
                    imResAirName = fullfile(floder_save_im,[SeText,'-imBinary-step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-start-air','.tif']);
                    imwrite(imrotate(imResidual_air,-90),imResAirName);
                    imResAirName2 = fullfile(floder_save_im,[SeText,'-imBinary-step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-start-air2','.tif']);
                    imwrite(imrotate(imResidual_air2,-90),imResAirName2);
                else if i==Lidx*(step_num)
                        imBwName = fullfile(floder_save_im,[SeText,'-imBinary-step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-end','.tif']);
                        imwrite(imBw_wo4pixels,imBwName);
                        imResAirName = fullfile(floder_save_im,[SeText,'-imBinary-step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-end-air','.tif']);
                        imwrite(imrotate(imResidual_air,-90),imResAirName);
                        imResAirName2 = fullfile(floder_save_im,[SeText,'-imBinary-step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-end-air2','.tif']);
                        imwrite(imrotate(imResidual_air2,-90),imResAirName2);
                    end
                end
            end
        end
    end
    Sa_ave(step_num,:) = mean(imSaturation(Lidx*(step_num-1)+2:Lidx*(step_num),:));
    Kr_ave(step_num,:) = mean(Kr(Lidx*(step_num-1)+2:Lidx*(step_num),:));
    Sa_final(step_num,:) = imSaturation(Lidx*(step_num),:);
    Kr_final(step_num,:) = Kr(Lidx*(step_num),:);
    Kr_air_ave(step_num,:) = mean(Kr_air(Lidx*(step_num-1)+2:Lidx*(step_num),:));
    Kr_air_final(step_num,:) = Kr_air(Lidx*(step_num),:);
    Kr_air2_ave(step_num,:) = mean(Kr_air2(Lidx*(step_num-1)+2:Lidx*(step_num),:));
    Kr_air2_final(step_num,:) = Kr_air2(Lidx*(step_num),:);
    fprintf(2,sprintf(['step',num2str(step_num),'Psi=',num2str(-dh_ave(step_num,:),'%.0f'),'-end  ']));
    toc
end

Sa_Kr_Save = [{'imNumber','Sa(0.85Tc)','Sa(Tc)','Sa(1.15Tc)','Kr(0.85Tc)',...
    'Kr(Tc)','Kr(1.15Tc)','Kr_air(0.85Tc)','Kr_air(Tc)','Kr_air(1.15Tc)',...
    'Kr_air2(0.85Tc)','Kr_air2(Tc)','Kr_air2(1.15Tc)'};...
    num2cell([imLabel_num_save_Nrow,imSaturation,Kr,Kr_air,Kr_air2])];
% xlswrite(Sa_xls_Name, Sa_Kr_Save, SeText, 'A1');

Sa_Kr_Ave_Save = [{'AveSa(0.85Tc)','AveSa(Tc)','AveSa(1.15Tc)','AveKr(0.85Tc)',...
    'AveKr(Tc)','AveKr(1.15Tc)','AveKr_air(0.85Tc)','AveKr_air(Tc)','AveKr_air(1.15Tc)',...
    'AveKr_air2(0.85Tc)','AveKr_air2(Tc)','AveKr_air2(1.15Tc)'};...
    num2cell([Sa_ave,Kr_ave,Kr_air_ave,Kr_air2_ave])];
% xlswrite(Sa_xls_Name, Sa_Kr_Ave_Save, SeText, 'O1');

Sa_Kr_final_Save = [{'dh_ave (mm)','finalSa(Tc)','finalKr(Tc)','finalKr_air(Tc)','finalKr_air2(Tc)'};...
    num2cell([dh_ave,Sa_final(:,2),Kr_final(:,2),Kr_air_final(:,2),Kr_air2_final(:,2)])];
% xlswrite(Sa_xls_Name, Sa_Kr_final_Save, SeText, 'AB1');
MatName = fullfile(folder_save,['Kr_Sa_Data-',SeText,DateText,'.mat']);
% save(MatName);
toc