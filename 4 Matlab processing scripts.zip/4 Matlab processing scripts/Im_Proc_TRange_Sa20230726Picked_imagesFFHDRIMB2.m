%% Comments in 20230726
% This script was modified to suitable for processing picked images (the
% first and the last 10 images of each pressure step

%%
clc;clear all;close all;
tic;

% %% create some figure placeholders that are nicely sized / positioned
% scrsz = get(0,'ScreenSize');
% figure('Position',[1 scrsz(4)/16 3*scrsz(3)/4 3*scrsz(4)/4])
% hold on

%% Load reference image & pick up reference window
folder_ref='G:\data_for_sharing\1 averaged reference image\'; % reference image
ref = imread([folder_ref,'ave_ref_image_for_FFH.tiff']);
ref = imrotate(ref,-0.8,'nearest','crop'); % rotate the image a little bit.

% Registration Reference: iref = row, jref = col 
iref = 1758; jref = 243; %i and j index of the center of the region to test for alignment
boxsize = 60;
nshift = 20;
idx = [1380 1720 18 128];%[row1 row2 col1 col2]
Wref = double(ref(idx(1):idx(2),idx(3):idx(4)));
roi_ref = [iref-boxsize iref+boxsize jref-boxsize jref+boxsize];

%% Settings for image display in video
% Define ROI for images
roi = [27 2048 1062 3072];%[row1 row2 col1 col2] %% the bottom & right edges are a little out of the Camera field.
imref = double(ref(roi(1):roi(2),roi(3):roi(4))); % cut off the image boundary
[row,col]=size(imref); % get the image size

folder1='G:\data_for_sharing\2 experimental images at the end of each sequence\FFH\2nd_DR-IMB\'; % raw images folder.
dinfo = dir(fullfile(folder1, '*.tiff')); % read the files' name and some other information. % f=fullfile(filepart1,...,filepartN) builds a full file specification from the specified folder and file names. On windows the file separator character is a backslash (\).
imagename=char({dinfo.name}); % Only pick the name info., it's a row vector. Note that this make iN be a cell array, not string array
N=size(imagename,1); % Count the number of files;
iNum = str2num(imagename(:,end-8:end-5)); % image number

%% Load & process data
% %% Read time/mass/pressure data
DATA=importdata([folder1,'test.txt']);  
Data=DATA.data; % here 1-Elapsed time (sec);2-scale;3-Pressure transducer (V);4-image number.
dh=89.85*Data(:,3)+60.495; % (mm)
t=Data(:,1);
m=Data(:,2);

% % 1st
% % Drainage: 12 pressure steps; Imbibition: 9 steps
% imPoint=[39,90;339,549;769,870;1060,1138;1330,1520;1701,1830;1959,2030;...
%     2329,2460;3129,3210;3329,3420;3539,3610;3749,3870;...
%     4089,4190;4359,4460;4849,4930;5089,5169;5289,5388;6149,6210;6329,6410;6499,6569;6689,6770;6780,N-1];
% 2nd
% Drainage: 10 pressure steps; Imbibition: 10 steps
imPoint=[16,66;235,326;535,746;856,956;1055,1196;1305,1437;1955,2086;2175,2244;2364,2436;2535,2636;...
2735,2786;3145,3194;3325,3406;3555,3636;3755,3835;3935,4035;4165,4243;...
4475,4576;4685,4746;4855,4956;5106,N-1];

imPoint(:,3) = imPoint(:,2)-imPoint(:,1)+1;
imTotalNum(1,1)=0;
for iTN = 1:length(imPoint)-1
    imTotalNum (iTN+1,1) = sum(imPoint(1:iTN,3));
end

%% Boundary condition
Mask_unglued = zeros(col,row);
Mask_unglued([37:1976],[42:1981]) = 1;

%% Parameters initialization
% threshold value and range
T_c=0.094;
T_ratio = -20:5:20;
T_point = (1+T_ratio./100).*T_c;

% settings for results saving
folder2='G:\data_for_sharing\2 experimental images at the end of each sequence\FFH\';
SeText='FFH_2nd_DR-IMB_';DateText='20230726_picked_images';
Sa_xls_Name = fullfile(folder2,[SeText,'Sa_TRange_',DateText,'.xls']);
MatName = fullfile(folder2,[SeText,'Sa_TRange_',DateText,'.mat']);
step_num_DP = 10; % the final step number of drainage process

% VideoName = fullfile(folder2,[SeText,DateText,'.avi'])
% V=VideoWriter(VideoName);
% V.FrameRate=1;
% open(V);

%% Process images
for step_num = 1:length(imPoint)-1 
    dh_ave(step_num,:)=mean(dh(imPoint(step_num,1)+1:imPoint(step_num,2)+1));
    
    for i = 11*(step_num-1)+1:11*(step_num)% imPoint(step_num,1)+1:imPoint(step_num+1,1) %
        t_reset(i,1)=t(iNum(i)+1)-t(imPoint(step_num,1)+1);
        % %% Read experimental images
        filename1 = fullfile(folder1,imagename(i,:)); % combine filename & folder name to char. or str.
    %     filename2 = fullfile(folder2,imagename(i,:));
        imraw = imread(filename1);
        imraw = imrotate(imraw,-0.8,'nearest','crop');
        % %% Register and shift image
        shift = full_pixel_shift_new(ref,imraw,iref,jref,boxsize,nshift);
        shf(i,:)=shift;
        imraw = apply_shift(imraw,shift);
        % %% Normalization 
        Wim = double(imraw(idx(1):idx(2),idx(3):idx(4)));
        R = Wref./Wim;
        R_norm = mean(R(:));
        % %% Absorbance Field
        imroi = double(imraw(roi(1):roi(2),roi(3):roi(4)));
        imroi = imroi .* R_norm;
        % imroi =rot90(imroi,3);
        imAbs_Field = log(imroi./imref);
        imAbs_Field(imref==0) = min(min(imAbs_Field)); % As the image was rotated a little bit, 0s were introduced into it.
        imAbs_Field90 = imrotate(imAbs_Field,-90);

    % %% try segmentation
        for j = 1:length(T_point)
            imBw_wo4pixels = imNor_to_imBwFinal( imAbs_Field90, Mask_unglued, T_point(j) );
          
            CC_new = bwconncomp(imBw_wo4pixels,4);
            imLabel_num_save(i,j) = CC_new.NumObjects;
            imLabel_num_save_Nrow(i,1)=iNum(i);
            
%             %%caculate the air saturation
            imSaturation(i,j)=sum(sum(imBw_wo4pixels))/(row*col);           
        end        
    end
    toc;
end

% save the saturation result.
Sa_save = [imLabel_num_save_Nrow,t_reset,imSaturation];
Sa_save_cell = mat2cell(Sa_save, ones(size(Sa_save,1),1), ones(size(Sa_save,2),1));
title = [{'imNumber','t_reset'}, num2cell(T_point)];
Sa_result = [title; Sa_save_cell];
% save(MatName);
toc;

