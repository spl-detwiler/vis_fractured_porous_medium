%% Notes of settings for different experiments.
% for the matlab script 'Im_Proc_TRange_Sa20210913~20211029'

%% Parameters of the 2 experimental models
sigma=0.0732; % interfacial tension (N/m)
rho=1000; % density (kg/m3)
g=9.8; % acceleration of gravity g (m/s2)
alpha1=18.76; % contact angle on smooth glass: 18.76��2.99(��)

% medium-flat model
d_thick = 5.99; % thickness of porous matrix (mm)
n_porosity = 0.327; % porosity
A_fracture = 23100.124; % fracture projected area (mm2)
A_matrix = A_fracture*0.6985; % 202306����ͼƬ��cad���ı�����%15495.82; % unglued matrix area (mm2)
b_h = 46.06*10^-3; % fracture hydraulic aperture (mm)
alpha2=30.79; % contact angle on MF: 30.79��2.65(��)
% finest-flat model
d_thick = 4.58; % thickness of porous matrix (mm)
n_porosity = 0.384; % porosity
A_fracture = 23042.253; % fracture projected area (mm2)
A_matrix = A_fracture*0.8141; % 202306����ͼƬ��cad���ı�����%16021.12; % unglued matrix area (mm2)
b_h = 51.44*10^-3; % fracture hydraulic aperture (mm)
alpha2=25.56; % contact angle on FF: 25.56��6.90(��)

%% FFH_DRIMB1
folder_ref='E:\zyliao\experiments\finest_flat2\Horizontal\'; % reference image
ref = imread([folder_ref,'ave_imref_FFH1222.tiff']);
ref = imrotate(ref,-0.8,'nearest','crop');
iref = 660; jref = 300; 
idx = [325 699 17 131];
roi = [27 2048 1062 3072];
folder1='E:\zyliao\experiments\finest_flat2\Horizontal\12_22_DR_IMB\';
DATA=importdata([folder1,'test.txt']);  
dh=89.85*Data(:,3)+60.495; 
% 1st
% Drainage: 12 pressure steps; Imbibition: 9 steps
imPoint=[39,90;339,549;769,870;1060,1138;1330,1520;1701,1830;1959,2030;...
    2329,2460;3129,3210;3329,3420;3539,3610;3749,3870;...
    4089,4190;4359,4460;4849,4930;5089,5169;5289,5388;6149,6210;6329,6410;6499,6569;6689,6770;6780,N-1];
Mask_unglued([37:1976],[42:1981]) = 1;
T_c=0.094;
T_ratio = -40:5:40;
folder2='E:\zyliao\experiments\finest_flat2\Horizontal\Sequence\';
SeText='FFH_DRIMB1_';DateText='20210914';
step_num_DP = 12; % the final step number of drainage process
step_num_DRstart=6;step_num_IMBend=20; % (step_num_IMBend=19);

%% FFH_DRIMB2
folder_ref='E:\zyliao\experiments\finest_flat2\Horizontal\'; 
iref = 1758; jref = 243; 
idx = [1380 1720 18 128];
folder1='E:\zyliao\experiments\finest_flat2\Horizontal\12_23_DR_IMB\';
% 2nd
% Drainage: 10 pressure steps; Imbibition: 10 steps
imPoint=[16,66;235,326;535,746;856,956;1055,1196;1305,1437;1955,2086;2175,2244;2364,2436;2535,2636;...
2735,2786;3145,3194;3325,3406;3555,3636;3755,3835;3935,4035;4165,4243;...
4475,4576;4685,4746;4855,4956;5106,N-1];
folder2='E:\zyliao\experiments\finest_flat2\Horizontal\Sequence\';
SeText='FFH_DRIMB2_';DateText='20210914';
step_num_DP = 10;
step_num_DRstart=4;step_num_IMBend=19; % (step_num_IMBend=18);

%% FFV_DRIMB1
folder_ref='E:\zyliao\experiments\finest_flat2\Vertical\'; % reference image
ref = imread([folder_ref,'ave_imref_FFV1202.tiff']);
ref = imrotate(ref,-0.8,'nearest','crop');
iref = 654; jref = 297; 
idx = [325 684 17 131];
roi = [27 2048 1062 3072];
folder1='E:\zyliao\experiments\finest_flat2\Vertical\1202DR_IMB1\';
DATA=importdata([folder1,'1202V_DR_IMB1.txt']);  
dh=87.473*Data(:,3)+27.502-208.5; 
% 1st
% Drainage: 9 pressure steps; Imbibition: 9 steps
imPoint=[19,119;209,309;409,509;659,760;809,960;1059,1310;1409,1559;1659,1809;1909,2139;...
    2309,2409;2489,2569;2659,2739;2859,2959;3029,3130;3209,3310;3459,3590;3669,3769;3859,3959;4000,N-1];
Mask_unglued([37:1976],[42:1981]) = 1;
T_c=0.094;
T_ratio = -40:5:40;
folder2='E:\zyliao\experiments\finest_flat2\Vertical\Sequence\';
SeText='FFV_DRIMB1_';DateText='20210914';
step_num_DP = 9; 
step_num_DRstart=5;step_num_IMBend=17; % (step_num_IMBend=17);
dh_ave=dh_ave+76;

%% FFV_DRIMB2
folder1='E:\zyliao\experiments\finest_flat2\Vertical\1203DR_IMB2\';
DATA=importdata([folder1,'1203V_DR_IMB2.txt']); 
% 2nd
% Drainage: 14 pressure steps; Imbibition: 8 steps
imPoint=[49,100;199,400;489,600;949,1050;1129,1230;1309,1429;1529,1630;...
    1799,1900;1999,2100;2199,2360;2429,2780;2899,3000;3099,3210;3339,3440;...
    3599,3700;3799,3900;3999,4100;4449,4580;4649,4750;4869,5000;5089,5200;5299,5659;5709,N-1];
folder2='E:\zyliao\experiments\finest_flat2\Vertical\Sequence\';
SeText='FFV_DRIMB2_';DateText='20210915';
step_num_DP = 14; 
step_num_DRstart=5;step_num_IMBend=21; % (step_num_IMBend=21);

%% MFH_DRIMB1
folder_ref='E:\zyliao\experiments\Mid_flat\Horizontal\'; % reference image
ref = imread([folder_ref,'ave_imref_MFH1123.tiff']);
% ref = imrotate(ref,-0.8,'nearest','crop');
iref = 1613; jref = 493; 
idx = [1409 1600 453 488];
roi = [39 2048 1053 3072];
folder1='E:\zyliao\experiments\Mid_flat\Horizontal\11_23_EXPERIMENT\';
DATA=importdata([folder1,'yay.txt']);  
dh=90.106*Data(:,3)+39.942-76; 
% 1st
% Drainage: 9 pressure steps; Imbibition: 7 steps
imPoint=[42,122;301,515;691,856;1190,1346;1579,1737;2144,2360;2986,3156;3256,3409;3471,3572;...
    3691,3797;3879,4086;4215,4297;4405,4505;4665,4775;4975,5052;5203,5340;5350,N-1];
Mask_unglued([36:1975],[31:1970]) = 1;
T_c=0.042;
T_ratio = -40:5:40;
folder2='E:\zyliao\experiments\Mid_flat\Horizontal\Sequence\';
SeText='MFH_DRIMB1_';DateText='20210919';
step_num_DP = 9; 
%         imraw = imrotate(imraw,-0.8,'nearest','crop');
step_num_DRstart=6;step_num_IMBend=15; % (step_num_IMBend=14);

%% MFH_DRIMB2
folder1='E:\zyliao\experiments\Mid_flat\Horizontal\11_24_EXPERIMENT\';
DATA=importdata([folder1,'data.txt']);  
% ref = imrotate(ref,-0.8,'nearest','crop');
% 2nd
% Drainage: 8 pressure steps; Imbibition: 7 steps
% modify 2569 to 2589
imPoint=[30,85;222,480;557,660;877,987;1097,1220;1319,1420;1489,1635;1842,1940;...
    2128,2235;2361,2473;2589,2700;2791,2922;3026,3140;3229,3369;3509,3663;3673,N-1];
folder2='E:\zyliao\experiments\Mid_flat\Horizontal\Sequence\';
SeText='MFH_DRIMB2_';DateText='20210919';
step_num_DP = 8;
step_num_DRstart=4;step_num_IMBend=14; % (step_num_IMBend=14);