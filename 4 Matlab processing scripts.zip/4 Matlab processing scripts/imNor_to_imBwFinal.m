function [ imBw_wo4pixels ] = imNor_to_imBwFinal( imAbs, Mask_unglued, T )
% Input:
%      imAbs: the normalized image (Absorbance Field) show the absorbance 
%      of light. imAbs = (log(im/imref).
%      Mask_unglued: A matrix that shows the location of unglued part of
%      porous glass (unglued=1, glued=0). It's used to clip off the boundary.
%      T: threshold value.
%
% Output:
%      imBw_wo4pixels: a final binary image that remove the clusters < 4
%      pixels

[Mask_unglued_r,Mask_unglued_c] = find(Mask_unglued==1);

im_mdf = medfilt2(imAbs,'indexed');
imBinary=im_mdf;
imBinary(imBinary>=T)=1;
imBinary(imBinary<T)=0;
imBw_unglued=bwselect(imBinary,Mask_unglued_c,Mask_unglued_r,4);
CC = bwconncomp(imBw_unglued,4);
stats = regionprops(CC,'Area'); 
nP_idx = find([stats.Area] > 4); 
imBw_wo4pixels = ismember(labelmatrix(CC),nP_idx);

end

