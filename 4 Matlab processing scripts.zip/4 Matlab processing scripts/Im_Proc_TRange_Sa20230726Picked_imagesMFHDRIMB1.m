%% Comments in 20230726
% This script was modified to suitable for processing picked images (the
% first and the last 10 images of each pressure step

%%
clc;clear all;close all;
tic;

% %% create some figure placeholders that are nicely sized / positioned
% scrsz = get(0,'ScreenSize');
% figure('Position',[1 scrsz(4)/16 3*scrsz(3)/4 3*scrsz(4)/4])
% hold on

%% Load reference image & pick up reference window
folder_ref='G:\data_for_sharing\1 averaged reference image\'; % reference image
ref = imread([folder_ref,'ave_ref_image_for_MFH.tiff']);
% ref = imrotate(ref,-0.8,'nearest','crop'); % rotate the image a little bit.

% Registration Reference: iref = row, jref = col 
iref = 1613; jref = 493; %i and j index of the center of the region to test for alignment
boxsize = 60;
nshift = 20;
idx = [1409 1600 453 488];%[row1 row2 col1 col2]
Wref = double(ref(idx(1):idx(2),idx(3):idx(4)));
roi_ref = [iref-boxsize iref+boxsize jref-boxsize jref+boxsize];

%% Settings for image display in video
% Define ROI for images
roi = [39 2048 1053 3072];%[row1 row2 col1 col2] %% the bottom & right edges are a little out of the Camera field.
imref = double(ref(roi(1):roi(2),roi(3):roi(4))); % cut off the image boundary
[row,col]=size(imref); % get the image size

folder1='G:\data_for_sharing\2 experimental images at the end of each sequence\MFH\1st_DR-IMB\'; % raw images folder.
dinfo = dir(fullfile(folder1, '*.tiff')); % read the files' name and some other information. % f=fullfile(filepart1,...,filepartN) builds a full file specification from the specified folder and file names. On windows the file separator character is a backslash (\).
imagename=char({dinfo.name}); % Only pick the name info., it's a row vector. Note that this make iN be a cell array, not string array
N=size(imagename,1); % Count the number of files;
iNum = str2num(imagename(:,end-8:end-5)); % image number

%% Load & process data
% %% Read time/mass/pressure data
DATA=importdata([folder1,'data.txt']);  
Data=DATA.data; % here 1-Elapsed time (sec);2-scale;3-Pressure transducer (V);4-image number.
dh=90.106*Data(:,3)+39.942-76;  % (mm)
t=Data(:,1);
m=Data(:,2);

% 2nd
% Drainage: 8 pressure steps; Imbibition: 7 steps
imPoint=[30,85;222,480;557,660;877,987;1097,1220;1319,1420;1489,1635;1842,1940;...
    2128,2235;2361,2473;2569,2700;2791,2922;3026,3140;3229,3369;3509,3663;3673,N-1];

imPoint(:,3) = imPoint(:,2)-imPoint(:,1)+1;
imTotalNum(1,1)=0;
for iTN = 1:length(imPoint)-1
    imTotalNum (iTN+1,1) = sum(imPoint(1:iTN,3));
end

%% Boundary condition
Mask_unglued = zeros(col,row);
Mask_unglued([36:1975],[31:1970]) = 1;

%% Parameters initialization
% threshold value and range
T_c=0.042;
T_ratio = -20:5:20;
T_point = (1+T_ratio./100).*T_c;

% settings for results saving
folder2='G:\data_for_sharing\2 experimental images at the end of each sequence\MFH\';
SeText='MFH_1st_DR-IMB_';DateText='20230726_picked_images';
Sa_xls_Name = fullfile(folder2,[SeText,'Sa_TRange_',DateText,'.xls']);
MatName = fullfile(folder2,[SeText,'Sa_TRange_',DateText,'.mat']);
step_num_DP = 8; % the final step number of drainage process

% VideoName = fullfile(folder2,[SeText,DateText,'.avi'])
% V=VideoWriter(VideoName);
% V.FrameRate=1;
% open(V);

%% Process images
for step_num = 1:length(imPoint)-1 
    dh_ave(step_num,:)=mean(dh(imPoint(step_num,1)+1:imPoint(step_num,2)+1));
    
    for i = 11*(step_num-1)+1:11*(step_num)% imPoint(step_num,1)+1:imPoint(step_num+1,1) %
        t_reset(i,1)=t(iNum(i)+1)-t(imPoint(step_num,1)+1);
        % %% Read experimental images
        filename1 = fullfile(folder1,imagename(i,:)); % combine filename & folder name to char. or str.
    %     filename2 = fullfile(folder2,imagename(i,:));
        imraw = imread(filename1);
%         imraw = imrotate(imraw,-0.8,'nearest','crop');
        % %% Register and shift image
        shift = full_pixel_shift_new(ref,imraw,iref,jref,boxsize,nshift);
        shf(i,:)=shift;
        imraw = apply_shift(imraw,shift);
        % %% Normalization 
        Wim = double(imraw(idx(1):idx(2),idx(3):idx(4)));
        R = Wref./Wim;
        R_norm = mean(R(:));
        % %% Absorbance Field
        imroi = double(imraw(roi(1):roi(2),roi(3):roi(4)));
        imroi = imroi .* R_norm;
        % imroi =rot90(imroi,3);
        imAbs_Field = log(imroi./imref);
        imAbs_Field(imref==0) = min(min(imAbs_Field)); % As the image was rotated a little bit, 0s were introduced into it.
        imAbs_Field90 = imrotate(imAbs_Field,-90);

    % %% try segmentation
        for j = 1:length(T_point)
            imBw_wo4pixels = imNor_to_imBwFinal( imAbs_Field90, Mask_unglued, T_point(j) );
          
            CC_new = bwconncomp(imBw_wo4pixels,4);
            imLabel_num_save(i,j) = CC_new.NumObjects;
            imLabel_num_save_Nrow(i,1)=iNum(i);
            
%             %%caculate the air saturation
            imSaturation(i,j)=sum(sum(imBw_wo4pixels))/(row*col);           
        end        
    end
    toc;
end

% save the saturation result.
Sa_save = [imLabel_num_save_Nrow,t_reset,imSaturation];
Sa_save_cell = mat2cell(Sa_save, ones(size(Sa_save,1),1), ones(size(Sa_save,2),1));
title = [{'imNumber','t_reset'}, num2cell(T_point)];
Sa_result = [title; Sa_save_cell];
% save(MatName);
toc;

